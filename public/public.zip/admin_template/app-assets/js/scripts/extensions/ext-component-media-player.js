/*=========================================================================================
    File Name: ext-component-media-player.js
    Description:extra components media player using Plyr plugin
    --------------------------------------------------------------------------------------
    Item Name: Frest HTML Admin Template
    Version: 1.0
    Author: PIXINVENT
    Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/
$(document).ready(function () {
  // video player  define
  var player = new Plyr(".video-player");
  // audio player define
  var player1 = new Plyr(".audio-player");
});
